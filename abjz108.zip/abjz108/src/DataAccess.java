import java.sql.*;

public class DataAccess {
    private Connection conn;

    public DataAccess() {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Establish a connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/mydatabase", "username", "password");
        } catch (Exception ex) {
            System.out.println("Error connecting to database: " + ex.getMessage());
        }
    }

    public Customer getCustomer(int customerId) {
        Customer customer = null;
        try {
            // Create a prepared statement
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM customers WHERE id=?");

            // Set the parameter values
            pstmt.setInt(1, customerId);

            // Execute the query
            ResultSet rs = pstmt.executeQuery();

            // Extract the customer information from the result set
            if (rs.next()) {
                customer = new Customer(rs.getInt("id"), rs.getString("name"), rs.getString("email"), rs.getString("phone"));
            }
        } catch (Exception ex) {
            System.out.println("Error getting customer information: " + ex.getMessage());
        }
        return customer;
    }

    public Account getAccount(int accountId) {
        Account account = null;
        try {
            // Create a prepared statement
            PreparedStatement pstmt = conn.prepareStatement("SELECT * FROM accounts WHERE id=?");

            // Set the parameter values
            pstmt.setInt(1, accountId);

            // Execute the query
            ResultSet rs = pstmt.executeQuery();

            // Extract the account information from the result set
            if (rs.next()) {
                account = new Account(rs.getInt("id"), rs.getInt("customerId"), rs.getDouble("balance"));
            }
        } catch (Exception ex) {
            System.out.println("Error getting account information: " + ex.getMessage());
        }
        return account;
    }

    public void addTransaction(int accountId, double amount, String type) {
        try {
            // Create a prepared statement
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO transactions (accountId, amount, type) VALUES (?, ?, ?)");

            // Set the parameter values
            pstmt.setInt(1, accountId);
            pstmt.setDouble(2, amount);
            pstmt.setString(3, type);

            // Execute the query
            pstmt.executeUpdate();
        } catch (Exception ex) {
            System.out.println("Error adding transaction: " + ex.getMessage());
        }
    }

    public void generateReconciliationReport() {
        // TODO: Implement reconciliation report generation
    }

    public void closeConnection() {
        try {
            // Close the database connection
            conn.close();
        } catch (Exception ex) {
            System.out.println("Error closing connection: " + ex.getMessage());
        }
    }
}
