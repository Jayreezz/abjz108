public class AccountManagementService {

    private AccountService accountService;

    // Constructor to initialize AccountService
    public AccountManagementService(AccountService accountService) {
        this.accountService = accountService;
    }

    // Method to move money between two accounts
    public void transferMoney(Account fromAccount, Account toAccount, double amount) throws InsufficientBalanceException, InvalidAccountException {
        // Check if the account being transferred from is a Current account
        if (!(fromAccount instanceof CurrentAccount)) {
            throw new InvalidAccountException("Only Current account can be used to make payments");
        }

        // Withdraw money from the 'fromAccount' and deposit into the 'toAccount'
        fromAccount.withdraw(amount);
        toAccount.deposit(amount);
    }

    // Method to calculate the interest earned on the Savings account
    public double calculateInterest(Account account) {
        if (account instanceof SavingsAccount) {
            SavingsAccount savingsAccount = (SavingsAccount) account;
            return savingsAccount.calculateInterest();
        } else {
            return 0.0;
        }
    }

    // Method to calculate the transaction fee charged on the transaction amount
    public double calculateTransactionFee(double amount) {
        double transactionFeePercentage = 0.05; // 0.05% transaction fee charged
        return (amount * transactionFeePercentage) / 100.0;
    }
}
