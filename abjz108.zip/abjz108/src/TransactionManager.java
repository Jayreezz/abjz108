import java.util.*;

public class TransactionManager {
    private Map<Integer, List<Transaction>> accountTransactions;
    private Map<Integer, List<Notification>> accountNotifications;

    public TransactionManager() {
        accountTransactions = new HashMap<>();
        accountNotifications = new HashMap<>();
    }

    // Perform a transaction for an account
    public void performTransaction(int accountId, double amount, String description) {
        Transaction transaction = new Transaction(accountId, amount, description);

        // Add transaction to account's transaction list
        if (!accountTransactions.containsKey(accountId)) {
            accountTransactions.put(accountId, new ArrayList<>());
        }
        accountTransactions.get(accountId).add(transaction);

        // Send notification to account holder
        if (!accountNotifications.containsKey(accountId)) {
            accountNotifications.put(accountId, new ArrayList<>());
        }
        Notification notification = new Notification(accountId, transaction);
        accountNotifications.get(accountId).add(notification);

        // Allow Bank Z to debit/credit customer's account for any transactions handled on behalf of Bank X
        BankZ.creditOrDebit(accountId, amount);
    }

    // Get all transactions for an account
    public List<Transaction> getTransactions(int accountId) {
        if (!accountTransactions.containsKey(accountId)) {
            return new ArrayList<>();
        }
        return accountTransactions.get(accountId);
    }

    // Get all notifications for an account
    public List<Notification> getNotifications(int accountId) {
        if (!accountNotifications.containsKey(accountId)) {
            return new ArrayList<>();
        }
        return accountNotifications.get(accountId);
    }
}

class Transaction {
    private int accountId;
    private double amount;
    private String description;
    private Date date;

    public Transaction(int accountId, double amount, String description) {
        this.accountId = accountId;
        this.amount = amount;
        this.description = description;
        this.date = new Date();
    }

    public int getAccountId() {
        return accountId;
    }

    public double getAmount() {
        return amount;
    }

    public String getDescription() {
        return description;
    }

    public Date getDate() {
        return date;
    }
}

class Notification {
    private int accountId;
    private Transaction transaction;
    private Date date;

    public Notification(int accountId, Transaction transaction) {
        this.accountId = accountId;
        this.transaction = transaction;
        this.date = new Date();
    }

    public int getAccountId() {
        return accountId;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    public Date getDate() {
        return date;
    }
}

class BankZ {
    public static void creditOrDebit(int accountId, double amount) {
        // Code to credit or debit the customer's account in Bank Z's system goes here
    }
}
