public class UserOnboardingService {

    private AccountService accountService;
    private CustomerService customerService;

    // Constructor to initialize AccountService and CustomerService
    public UserOnboardingService(AccountService accountService, CustomerService customerService) {
        this.accountService = accountService;
        this.customerService = customerService;
    }

    // Method to create a new customer record and associated Current and Savings accounts
    public Customer onboardNewCustomer(String name, String address, String email, String phone) {
        // Create a new customer record
        Customer customer = new Customer(name, address, email, phone);
        customerService.createCustomer(customer);

        // Create a Current account for the customer
        Account currentAccount = new CurrentAccount(customer);
        accountService.createAccount(currentAccount);

        // Create a Savings account for the customer
        Account savingsAccount = new SavingsAccount(customer);
        accountService.createAccount(savingsAccount);

        // Credit the Savings account with the joining bonus of R500.00
        double joiningBonus = 500.00;
        savingsAccount.deposit(joiningBonus);

        return customer;
    }
}
